// routes/auth.js
const express = require('express');

const { auth } = require('../middleware/auth');
const authController = require('../controller/authController');

const router = express.Router();

router.post('/register',authController.register);
router.post('/login',authController.login);
router.post('/logout', auth, authController.logout);
router.get('/profile', auth, authController.getProfile);

module.exports = router;