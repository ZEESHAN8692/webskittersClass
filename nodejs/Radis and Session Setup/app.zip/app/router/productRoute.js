const express = require('express');

const { auth } = require('../middleware/auth');
const { cache } = require('../middleware/cache');
const productController = require('../controller/productController');

const router = express.Router();

router.get('/', cache('products', 1800), productController.getAllProducts); // Cache for 30 minutes
router.get('/:id', cache('product', 1800), productController.getProduct);
router.post('/', auth, productController.createProduct);
router.put('/:id', auth, productController.updateProduct);
router.delete('/:id', auth, productController.deleteProduct);

module.exports = router;