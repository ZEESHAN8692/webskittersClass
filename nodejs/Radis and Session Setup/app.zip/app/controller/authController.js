const User = require("../model/user");

const jwt = require('jsonwebtoken');

class AuthController {

    generateToken = (userId) => {
        return jwt.sign({ id: userId }, process.env.JWT_SECRET, { expiresIn: '7d' });
    };

    async register(req, res) {
        try {
            const { username, email, password } = req.body;

            // Check if user exists
            const existingUser = await User.findOne({
                $or: [{ email }, { username }]
            });

            if (existingUser) {
                return res.status(400).json({
                    message: 'User already exists with this email or username'
                });
            }

            // Create user
            const user = new User({ username, email, password });
            await user.save();

            // Generate token
            const token = this.generateToken(user._id);

            res.status(201).json({
                message: 'User registered successfully',
                token,
                user: {
                    id: user._id,
                    username: user.username,
                    email: user.email,
                    role: user.role
                }
            });
        } catch (error) {
            res.status(500).json({ message: 'Server error', error: error.message });
        }
    };

    async login(req, res) {
        try {
            const { email, password } = req.body;

            // Find user
            const user = await User.findOne({ email });
            if (!user) {
                return res.status(400).json({ message: 'Invalid credentials' });
            }

            // Check password
            const isMatch = await user.comparePassword(password);
            if (!isMatch) {
                return res.status(400).json({ message: 'Invalid credentials' });
            }

            // Generate token
            const token = this.generateToken(user._id);

            // Store user session in Redis
            req.session.userId = user._id.toString();
            req.session.userRole = user.role;

            res.json({
                message: 'Login successful',
                token,
                user: {
                    id: user._id,
                    username: user.username,
                    email: user.email,
                    role: user.role
                }
            });
        } catch (error) {
            res.status(500).json({ message: 'Server error', error: error.message });
        }
    };

    async logout(req, res) {
        try {
            // Clear session
            req.session.destroy(async (err) => {
                if (err) {
                    return res.status(500).json({ message: 'Logout failed' });
                }

                // Clear user-related cache
                await clearCache([`user:${req.user.id}:*`]);

                res.json({ message: 'Logout successful' });
            });
        } catch (error) {
            res.status(500).json({ message: 'Server error', error: error.message });
        }
    };

    async getProfile(req, res) {
        try {
            res.json({
                user: {
                    id: req.user._id,
                    username: req.user.username,
                    email: req.user.email,
                    role: req.user.role
                }
            });
        } catch (error) {
            res.status(500).json({ message: 'Server error', error: error.message });
        }
    };
}

module.exports = new AuthController();