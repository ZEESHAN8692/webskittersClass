const Product = require('../model/product');
const { clearCache } = require('../middleware/cache');
const mongoose = require('mongoose');


class ProductController {
    async getAllProducts(req, res) {
        try {
            const { page = 1, limit = 10, category, search } = req.query;

            let query = {};

            if (category) {
                query.category = category;
            }

            if (search) {
                query.name = { $regex: search, $options: 'i' };
            }

            // const products = await Product.find(query)
            //   .populate('createdBy', 'username email')
            //   .limit(limit * 1)
            //   .skip((page - 1) * limit)
            //   .sort({ createdAt: -1 });

            const products = await Product.aggregate([
                { $match: query },
                { $sort: { createdAt: -1 } },
                { $skip: (page - 1) * limit },
                { $limit: limit },
                {
                    $lookup: {
                        from: 'users',
                        localField: 'createdBy',
                        foreignField: '_id',
                        as: 'createdBy'
                    }
                },
                {
                    $project: {
                        name: 1,
                        description: 1,
                        price: 1,
                        category: 1,
                        inStock: 1,
                        createdBy: { $arrayElemAt: ['$createdBy', 0] }
                    }
                }
            ]);


            const total = await Product.countDocuments(query);

            res.json({
                products,
                totalPages: Math.ceil(total / limit),
                currentPage: page,
                total
            });
        } catch (error) {
            res.status(500).json({ message: 'Server error', error: error.message });
        }
    };


    async getProduct(req, res) {
        try {
            // const product = await Product.findById(req.params.id)
            //   .populate('createdBy', 'username email');
            const product = await Product.aggregate([
                { $match: { _id: require('mongoose').Types.ObjectId(req.params.id) } },
                {
                    $lookup: {
                        from: 'users',
                        localField: 'createdBy',
                        foreignField: '_id',
                        as: 'createdBy'
                    }
                },
                {
                    $project: {
                        name: 1,
                        description: 1,
                        price: 1,
                        category: 1,
                        inStock: 1,
                        createdBy: { $arrayElemAt: ['$createdBy', 0] }
                    }
                }
            ]);
            if (!product) {
                return res.status(404).json({ message: 'Product not found' });
            }

            res.json(product);
        } catch (error) {
            res.status(500).json({ message: 'Server error', error: error.message });
        }
    };

    async createProduct(req, res) {
        try {
            const { name, description, price, category } = req.body;

            const product = new Product({
                name,
                description,
                price,
                category,
                createdBy: req.user.id
            });

            await product.save();
            //await product.populate('createdBy', 'username email');
            await product.aggregate([
                { $match: { _id: product._id } },
                {
                    $lookup: {
                        from: 'users',
                        localField: 'createdBy',
                        foreignField: '_id',
                        as: 'createdBy'
                    }
                },
                {
                    $project: {
                        name: 1,
                        description: 1,
                        price: 1,
                        category: 1,
                        inStock: 1,
                        createdBy: { $arrayElemAt: ['$createdBy', 0] }
                    }
                }
            ]);

            // Clear relevant cache
            await clearCache(['products:*', `user:${req.user.id}:products:*`]);

            res.status(201).json({
                message: 'Product created successfully',
                product
            });
        } catch (error) {
            res.status(500).json({ message: 'Server error', error: error.message });
        }
    };

    async updateProduct(req, res) {
        try {
            const product = await Product.findById(req.params.id);

            if (!product) {
                return res.status(404).json({ message: 'Product not found' });
            }

            // Check ownership or admin role
            if (product.createdBy.toString() !== req.user.id && req.user.role !== 'admin') {
                return res.status(403).json({ message: 'Access denied' });
            }

            const updatedProduct = await Product.findByIdAndUpdate(
                req.params.id,
                req.body,
                { new: true, runValidators: true }
            ).populate('createdBy', 'username email');

            // Clear relevant cache
            await clearCache([
                'products:*',
                `product:${req.params.id}`,
                `user:${req.user.id}:products:*`
            ]);

            res.json({
                message: 'Product updated successfully',
                product: updatedProduct
            });
        } catch (error) {
            res.status(500).json({ message: 'Server error', error: error.message });
        }
    };


    async deleteProduct(req, res) {
        try {
            const product = await Product.findById(req.params.id);

            if (!product) {
                return res.status(404).json({ message: 'Product not found' });
            }

            // Check ownership or admin role
            if (product.createdBy.toString() !== req.user.id && req.user.role !== 'admin') {
                return res.status(403).json({ message: 'Access denied' });
            }

            await Product.findByIdAndDelete(req.params.id);

            // Clear relevant cache
            await clearCache([
                'products:*',
                `product:${req.params.id}`,
                `user:${req.user.id}:products:*`
            ]);

            res.json({ message: 'Product deleted successfully' });
        } catch (error) {
            res.status(500).json({ message: 'Server error', error: error.message });
        }
    };

}




// async function updateProduct(req, res) {
//   try {
//     const product = await Product.findById(req.params.id);

//     if (!product) {
//       return res.status(404).json({ message: 'Product not found' });
//     }

//     // Check ownership or admin role
//     if (product.createdBy.toString() !== req.user.id && req.user.role !== 'admin') {
//       return res.status(403).json({ message: 'Access denied' });
//     }

//     // Update the product
//     await Product.updateOne(
//       { _id: req.params.id },
//       req.body,
//       { runValidators: true }
//     );

//     // Aggregate to get the updated document with populated `createdBy`
//     const updatedProductArr = await Product.aggregate([
//       {
//         $match: { _id: new mongoose.Types.ObjectId(req.params.id) }
//       },
//       {
//         $lookup: {
//           from: 'users',
//           localField: 'createdBy',
//           foreignField: '_id',
//           as: 'createdBy'
//         }
//       },
//       { $unwind: '$createdBy' },
//       {
//         $project: {
//           name: 1,
//           description: 1,
//           price: 1,
//           createdAt: 1,
//           updatedAt: 1,
//           createdBy: {
//             username: 1,
//             email: 1
//           }
//         }
//       }
//     ]);

//     const updatedProduct = updatedProductArr[0];

//     // Clear relevant cache
//     await clearCache([
//       'products:*',
//       `product:${req.params.id}`,
//       `user:${req.user.id}:products:*`
//     ]);

//     res.json({
//       message: 'Product updated successfully',
//       product: updatedProduct
//     });

//   } catch (error) {
//     res.status(500).json({ message: 'Server error', error: error.message });
//   }
// }







module.exports = new ProductController();