const { redisClient } = require('../config/redis');

const cache = (keyPrefix, expireTime = 3600) => {
  return async (req, res, next) => {
    if (req.method !== 'GET') {
      return next();
    }

    const key = `${keyPrefix}:${req.originalUrl || req.url}`;

    try {
      const cachedData = await redisClient.get(key);

      if (cachedData) {
        console.log('Serving from cache:', key);
        return res.json(JSON.parse(cachedData));
      }

      const originalJson = res.json;
      res.json = function (data) {
        redisClient.setEx(key, expireTime, JSON.stringify(data))
          .catch(err => console.error('Redis set error:', err));
        return originalJson.call(this, data);
      };

      next();
    } catch (error) {
      console.error('Cache middleware error:', error);
      next();
    }
  };
};

const clearCache = async (patterns) => {
  try {
    for (const pattern of patterns) {
      const keys = await redisClient.keys(pattern);
      if (keys.length > 0) {
        await redisClient.del(keys);
        console.log(`Cleared cache for pattern: ${pattern}`);
      }
    }
  } catch (error) {
    console.error('Error clearing cache:', error);
  }
};

module.exports = { cache, clearCache };
