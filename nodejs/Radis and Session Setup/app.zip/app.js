// app.js
require('dotenv').config();
const express = require('express');
const session = require('express-session');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const connectDB = require('./app/config/database');
const { redisClient,connectRedis } = require('./app/config/redis');
const RedisStore = require('connect-redis')(session);

const authRoutes = require('./app/router/authRouter');
const productRoutes = require('./app/router/productRoute');

const app = express();

// Connect MongoDB
connectDB();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100,
  message: 'Too many requests from this IP, please try again later.'
});
app.use(limiter);

// Redis Session Store
connectRedis().then(() => {
  app.use(
    session({
      store: new RedisStore({ client: redisClient }),
      secret: process.env.SESSION_SECRET || 'your-secret',
      resave: false,
      saveUninitialized: false,
      cookie: {
        secure: process.env.NODE_ENV === 'production',
        httpOnly: true,
        maxAge: 24 * 60 * 60 * 1000,
      },
    })
  );
});



// Routes
app.use('/api/auth', authRoutes);
app.use('/api/products', productRoutes);


// Health check
app.get('/health', async (req, res) => {
  const healthcheck = {
    uptime: process.uptime(),
    message: 'OK',
    timestamp: Date.now(),
    services: {
      database: 'unknown',
      redis: 'unknown'
    }
  };

  try {
    const mongoose = require('mongoose');
    healthcheck.services.database = mongoose.connection.readyState === 1 ? 'connected' : 'disconnected';

    await redisClient.ping();
    healthcheck.services.redis = 'connected';
  } catch (error) {
    healthcheck.services.redis = 'disconnected';
  }

  const status =
    healthcheck.services.database === 'connected' &&
    healthcheck.services.redis === 'connected'
      ? 200
      : 503;

  res.status(status).json(healthcheck);
});




// Error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: 'Something went wrong!' });
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
});
