require('dotenv').config();
const Redis=require('ioredis');



const redisClient=new Redis({
    port:process.env.REDIS_PORT||6379,
    host:process.env.REDIS_HOST||'127.0.0.1',
    password:process.env.REDIS_PASSWORD||'',
});
// Test Redis connection
redisClient.on('connect',()=>console.log('Redis connected'));
redisClient.on('error',()=>console.log('Redis error'));

//Working with Redis Data Structures

redisClient.set('user:1',JSON.stringify({name:'John',age:30,phone:'9898565236'}), (err, reply) => {
    if (err) {
        console.error('Error setting value:', err);
    } else {
        console.log('Value set:', reply);
    }
});

redisClient.get('user:1', (err, reply) => {
    if (err) {
        console.error('Error getting value:', err);
    } else {
        console.log('Value:', reply);
    }
});


//List Operations

redisClient.lpush('users', 'John', 'Alice', 'Bob', 'raju', (err, reply) => {
    if (err) {
        console.error('Error pushing value:', err);
    } else {
        console.log('Value pushed:', reply);
    }
});

redisClient.lpop('users', (err, reply) => {
    if (err) {
        console.error('Error popping value:', err);
    } else {
        console.log('Value popped:', reply);
    }
});

//Hashes (Storing Objects)

redisClient.hset('user:2', 'name', 'Alice', 'age', 25, 'phone', '9876543210', (err, reply) => {
    if (err) {
        console.error('Error setting hash:', err);
    } else {
        console.log('Hash set:', reply);
    }
});
