(async () => {
  require('dotenv').config();
  const express = require('express');
  const session = require('express-session');
  const cors = require('cors');
  const rateLimit = require('express-rate-limit');
  const connectDB = require('./app/config/database');
  const { redisClient, connectRedis } = require('./app/config/redis');
  const RedisStore = require('connect-redis').default;
  const authRoutes = require('./app/router/authRouter');
  const productRoutes = require('./app/router/productRoute');

  const app = express();

  // Connect to databases
  connectDB();
  await connectRedis(); // await connection!

  // Rate limiting
  const limiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 100,
    message: 'Too many requests from this IP, please try again later.'
  });
  app.use(limiter);

  // Middleware
  app.use(cors());
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Session configuration with Redis store
  app.use(session({
    store: new RedisStore({ client: redisClient }),
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: process.env.NODE_ENV === 'production',
      httpOnly: true,
      maxAge: 24 * 60 * 60 * 1000
    }
  }));

  // Routes
  app.use('/api/auth', authRoutes);
  app.use('/api/products', productRoutes);

  // Health check endpoint
  app.get('/health', async (req, res) => {
    // ... your health check code
  });

  // Error and 404 handlers
  app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ message: 'Something went wrong!' });
  });

  app.use('*', (req, res) => {
    res.status(404).json({ message: 'Route not found' });
  });

  const PORT = process.env.PORT || 3000;

  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
    console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
  });
})();
